const express = require('express');
const fs = require('fs');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static('public'));
app.use(express.json());

// Endpoint to get resources
app.get('/api/resources', (req, res) => {
    fs.readFile('resources.json', (err, data) => {
        if (err) {
            return res.status(500).send('Error reading resources');
        }
        res.send(JSON.parse(data));
    });
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
