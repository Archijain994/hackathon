const resources = [
    { name: "Therapist Locator", link: "https://www.therapistlocator.com" },
    { name: "Crisis Hotline", link: "https://www.crisishotline.com" },
    { name: "Support Groups", link: "https://www.supportgroups.com" }
];

function displayResources() {
    const resourceList = document.getElementById('resource-list');
    resources.forEach(resource => {
        const listItem = document.createElement('li');
        listItem.innerHTML = `
            <div class="resource-card">
                <a href="${resource.link}" target="_blank" style="text-decoration: none; color: #333;">
                    <h3>${resource.name}</h3>
                    <p>Click here for more information.</p>
                </a>
            </div>
        `;
        resourceList.appendChild(listItem);
    });
}

// Existing functions remain unchanged

function filterResources() {
    const searchInput = document.getElementById('search').value.toLowerCase();
    const filteredResources = resources.filter(resource => 
        resource.name.toLowerCase().includes(searchInput)
    );
    
    const resourceList = document.getElementById('resource-list');
    resourceList.innerHTML = ''; // Clear the current list
    filteredResources.forEach(resource => {
        const listItem = document.createElement('li');
        listItem.innerHTML = `<a href="${resource.link}" target="_blank">${resource.name}</a>`;
        resourceList.appendChild(listItem);
    });
}

function openChat() {
    const chatWindow = document.getElementById('chat-window');
    chatWindow.innerHTML = `
        <h3>Chat Support</h3>
        <p>How can we help you today?</p>
        <textarea placeholder="Type your message..."></textarea>
        <button onclick="sendMessage()">Send</button>
    `;
    chatWindow.style.display = 'block';
}

function sendMessage() {
    const inputField = document.getElementById('chat-input');
    const message = inputField.value.trim();
    
    if (message) {
        const chatMessages = document.querySelector('.chat-messages');
        const messageElement = document.createElement('div');
        messageElement.textContent = message;
        messageElement.className = 'user-message'; // Optional: Add a class for user messages
        chatMessages.appendChild(messageElement);
        inputField.value = ''; // Clear input field
        chatMessages.scrollTop = chatMessages.scrollHeight; // Auto-scroll to latest message
    } else {
        alert("Please type a message before sending.");
    }
}


// Initial display of resources
window.onload = displayResources;
function displayResources() {
    const resourceList = document.getElementById('resource-list');
    resourceList.innerHTML = ''; // Clear previous resources
    resources.forEach(resource => {
        const listItem = document.createElement('li');
        listItem.className = 'resource-card'; // Add class for styling
        listItem.innerHTML = `<a href="${resource.link}" target="_blank">${resource.name}</a>`;
        resourceList.appendChild(listItem);
    });
}
function scrollToResources() {
    document.getElementById('resources').scrollIntoView({ behavior: 'smooth' });
}

